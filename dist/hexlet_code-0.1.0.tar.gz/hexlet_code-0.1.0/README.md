### Hexlet tests and linter status:
[![Actions Status](https://github.com/Heavybrain/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Heavybrain/python-project-49/actions)

<a href="https://codeclimate.com/github/Heavybrain/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/e903f4ef0d41e531d007/maintainability" /></a>

<a href="https://asciinema.org/a/62jkUsDVn48W3de6CdtQA6FET" target="_blank"><img src="https://asciinema.org/a/62jkUsDVn48W3de6CdtQA6FET.svg" /></a>

<a href="https://asciinema.org/a/u1YrSYB5nwHKGU87khG5DrsMX" target="_blank"><img src="https://asciinema.org/a/u1YrSYB5nwHKGU87khG5DrsMX.svg" /></a>
