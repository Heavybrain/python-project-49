#!/usr/bin/env python3
import sys
sys.path.append('/home/heavybrain/projects/python-project-49/brain_games/')
from brain_games.games.nod_game import nod_counter


def main():
    nod_counter()


if __name__ == '__main__':
    main()