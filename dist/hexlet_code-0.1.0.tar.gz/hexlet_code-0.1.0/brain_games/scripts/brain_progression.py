#!/usr/bin/env python3
import sys
sys.path.append('/home/heavybrain/projects/python-project-49/brain_games/')
from brain_games.games.progression_game import prog_game


def main():
    prog_game()


if __name__ == '__main__':
    main()