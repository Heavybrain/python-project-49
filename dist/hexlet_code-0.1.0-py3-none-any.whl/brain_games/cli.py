
def welcome_user():
    print("Welcom to the Brain Games!")
    name = input('May I have Your name? ')
    print(f"Hello, {name}!")
    return name
